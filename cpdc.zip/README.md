# Chemistry Program Data Center

Adalah website Sistem Informasi untuk Jurusan Kimia, Fakultas Matematika dan Ilmu Pengetahuan Alam Universitas Lampung.
Website ini digunakan untuk melakukan pendataan terhadap Dosen, Mahasiswa, Aktivitas, dan Barang.

-------------------------------------------

## Fitur


-------------------------------------------

## Team Project
| No | Nama | NPM | Role |
| ------- | ------- | ------- | ------- |
| 1| Muhammad Febrian Hasibuan | 2017051033 | Back-End |
| 2| Yogi Andaru | 2017051062 | Front-End |
| 3| Putu Putra Eka Persada | 2057051016 | UI/UX Designer & Front-End |

-------------------------------------------

## Lisensi
MIT License
[2023] [Author]

-------------------------------------------
## Dokumentasi


